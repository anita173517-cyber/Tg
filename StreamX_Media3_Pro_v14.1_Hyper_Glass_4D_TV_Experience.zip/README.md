# StreamX Media3 Pro — v14.1 Hyper-Glass 4D TV Experience (512MB TV & Mobile)

StreamX Media3 Pro v14.0 upgrades the entire application inside and out while preserving all existing Xtream Codes, M3U/M3U8, XMLTV EPG, SXB2 fast cache, encrypted profile storage, Parental PIN, Auto-Boot, and 512MB low-RAM capabilities.

## Key Upgrades in v14.0
1. **4D Crystal Glass Modal Dialog & UI System**: Every popup screen (`Load M3U`, `Xtream VIP Login`, `Audio/Video Quality & Buffer`, `Buffer Profiles`, `4D Studio Themes`, `512MB RAM Telemetry Monitor`, `Saved Accounts`, `XMLTV EPG`, `Parental PIN`) now renders inside a custom 4-layer 3D/4D beveled glass modal with custom 3D vector icons, two-line option cards, neon status pills, and 4D sunken crystal input fields.
2. **4D Channel Drawer Cards & Custom Category Spinner**: Each channel in the sidebar displays a 3D neon number pill, RGB_565 logo (or 3D crystal TV icon), bold channel name, live EPG/category subtitle, and `★` / `● LIVE` badge.
3. **Ultra-Fast Zapping & Zero-Allocation Parsing**:
   - `SeekParameters.CLOSEST_SYNC`, asynchronous MediaCodec buffer queueing, `25ms` remote key-repeat debounce, and direction-aware DNS + socket pre-warming (`StreamPreFetcher`).
   - Zero-allocation 64-bit FNV-1a composite hashing (`M3uParser.fnv1a64NormalizedPair`) and 64KB I/O buffers in `ChannelCacheStore`, `M3uParser`, and `XtreamRepository`.
4. **Fixed GitHub Actions Workflow**: `.github/workflows/build_apk.yml` builds `assembleRelease` cleanly without the `-x lintVitalRelease` task-not-found error.


## v14.1 TV Experience Refresh
- Full 4D-glass UI polish across navigation, channel cards, drawer, dialogs, fields, badges and remote-focus states.
- Compact 96dp channel-zap HUD; preserved all original view IDs and button actions.
- Existing 512MB memory protections and preload-to-playback path retained; no second player added.
- Build toolchain kept aligned with the supplied workflow: JDK 17, Gradle 8.13, SDK 36, AGP 8.13.2, Media3 1.11.1.
