package com.harindra.iptvpro

import android.util.Log
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.Reader
import java.io.StringReader
import java.util.Calendar
import java.util.TimeZone

object XmltvParser {
    fun parseNowNext(
        xml: String,
        relevantChannelIds: Set<String>? = null,
        shouldCancel: () -> Boolean = { false }
    ): Map<String, Pair<String, String>> {
        return parseNowNext(StringReader(xml), relevantChannelIds, shouldCancel)
    }

    fun parseNowNext(
        reader: Reader,
        relevantChannelIds: Set<String>? = null,
        shouldCancel: () -> Boolean = { false }
    ): Map<String, Pair<String, String>> {
        val parser = Xml.newPullParser()
        parser.setInput(reader)

        val now = System.currentTimeMillis()
        val currentMap = HashMap<String, String>(1024)
        val nextMap = HashMap<String, Pair<Long, String>>(1024)
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))

        var event = parser.eventType
        var channelId = ""
        var start = ""
        var stop = ""
        var title = ""
        var inProgramme = false
        var skipCurrentProgramme = false
        var tagCounter = 0

        try {
            while (event != XmlPullParser.END_DOCUMENT) {
                tagCounter++
                if (tagCounter % 2000 == 0 && shouldCancel()) break

                when (event) {
                    XmlPullParser.START_TAG -> when (parser.name) {
                        "programme" -> {
                            channelId = parser.getAttributeValue(null, "channel")?.trim().orEmpty()
                            skipCurrentProgramme = channelId.isEmpty() ||
                                (relevantChannelIds != null &&
                                    !relevantChannelIds.contains(channelId) &&
                                    !relevantChannelIds.contains(channelId.lowercase()))
                            if (!skipCurrentProgramme) {
                                inProgramme = true
                                start = parser.getAttributeValue(null, "start").orEmpty()
                                stop = parser.getAttributeValue(null, "stop").orEmpty()
                                title = ""
                            } else {
                                inProgramme = false
                            }
                        }
                        "title" -> if (inProgramme && title.isEmpty()) {
                            title = parser.nextText().trim()
                        }
                    }
                    XmlPullParser.END_TAG -> if (parser.name == "programme" && inProgramme) {
                        if (channelId.isNotEmpty() && title.isNotEmpty()) {
                            val startMs = parseXmltvTimestampFast(start, cal)
                            val stopMs = parseXmltvTimestampFast(stop, cal)
                            if (startMs > 0L && stopMs > startMs) {
                                if (now in startMs until stopMs) {
                                    currentMap[channelId] = title
                                } else if (startMs > now) {
                                    val existingNext = nextMap[channelId]
                                    if (existingNext == null || startMs < existingNext.first) {
                                        nextMap[channelId] = startMs to title
                                    }
                                }
                            }
                        }
                        inProgramme = false
                    }
                }
                event = parser.next()
            }
        } catch (e: Exception) {
            Log.w("StreamX", "XMLTV stream parse warning", e)
        }

        val allIds = HashSet<String>(currentMap.size + nextMap.size).apply {
            addAll(currentMap.keys)
            addAll(nextMap.keys)
        }
        val result = HashMap<String, Pair<String, String>>(allIds.size)
        for (id in allIds) {
            val cur = currentMap[id] ?: "No current listing"
            val nxt = nextMap[id]?.second ?: "No upcoming listing"
            val pair = cur to nxt
            result[id] = pair
            result.putIfAbsent(id.lowercase(), pair)
        }
        return result
    }

    /**
     * Zero-SimpleDateFormat parser for XMLTV timestamps ("yyyyMMddHHmmss +0000" or "yyyyMMddHHmmss").
     */
    private fun parseXmltvTimestampFast(raw: String, utcCalendar: Calendar): Long {
        val s = raw.trim()
        if (s.length < 14) return -1L
        for (i in 0 until 14) {
            if (s[i] < '0' || s[i] > '9') return -1L
        }
        val year = (s[0] - '0') * 1000 + (s[1] - '0') * 100 + (s[2] - '0') * 10 + (s[3] - '0')
        val month = (s[4] - '0') * 10 + (s[5] - '0') - 1
        val day = (s[6] - '0') * 10 + (s[7] - '0')
        val hour = (s[8] - '0') * 10 + (s[9] - '0')
        val minute = (s[10] - '0') * 10 + (s[11] - '0')
        val second = (s[12] - '0') * 10 + (s[13] - '0')

        utcCalendar.clear()
        utcCalendar.set(year, month, day, hour, minute, second)
        var timeMs = utcCalendar.timeInMillis

        // Parse optional timezone offset e.g. "+0530" or "-0400"
        var idx = 14
        while (idx < s.length && s[idx] == ' ') idx++
        if (idx + 5 <= s.length && (s[idx] == '+' || s[idx] == '-')) {
            val sign = if (s[idx] == '+') 1 else -1
            val tzH = (s[idx + 1] - '0') * 10 + (s[idx + 2] - '0')
            val tzM = (s[idx + 3] - '0') * 10 + (s[idx + 4] - '0')
            if (tzH in 0..14 && tzM in 0..59) {
                val offsetMillis = sign * ((tzH * 60L + tzM) * 60_000L)
                timeMs -= offsetMillis
            }
        }
        return timeMs
    }
}
